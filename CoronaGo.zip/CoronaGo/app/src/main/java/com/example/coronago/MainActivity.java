package com.example.coronago;

import androidx.appcompat.app.AppCompatActivity;
import androidx.gridlayout.widget.GridLayout;

import android.content.pm.ActivityInfo;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    int activePlayer=0;
    int[] array={2,3,4,5,6,7,8,9,10};
    int i=0;
    int win=-1;
    boolean game=true;
    int a=0;
    int[] tags={0,0,0,0,0,0,0,0,0};
    int tagsPointer=0;
    int activeState=1;
    int wins=0;
    int g=1;
    ImageView token;
    MediaPlayer mediaPlayer;

    public void appear(View view) {

        token = (ImageView) view;
        int z=(Integer.parseInt(token.getTag().toString()))-1;
        tagsPointer=z;
        if(tags[tagsPointer]==0 && wins==0){

            token.setTranslationY(-1000f);

            if (activePlayer == 1) {

                activePlayer = 0;
                if (array[z] >= 2 && i < 9) {
                    token.setImageResource(R.drawable.sanitizer);
                    mediaPlayer= MediaPlayer.create(this, R.raw.san);
                    mediaPlayer.start();
                    array[z] = 0;
                    win=2;
                    i=i+1;
                    tags[tagsPointer]=1;
                }

                token.animate().translationYBy(1000f).rotation(g*360).setDuration(600);
                winner(array,win);
            }
            else {

                activePlayer = 1;
                if (array[z] >= 2 && i < 9) {
                    token.setImageResource(R.drawable.corona);
                    mediaPlayer= MediaPlayer.create(this, R.raw.virus);
                    mediaPlayer.start();
                    array[z] = 1;
                    i=i+1;
                    win=1;
                    tags[tagsPointer]=1;

                }

                token.animate().translationYBy(1000f).rotation(g*360).setDuration(600);
                winner(array,win);
            }
        }
    }

    public void winner(int[] array, int win){

        TextView textView=(TextView) findViewById(R.id.winnerMessage);

        LinearLayout linearLayout= (LinearLayout) findViewById(R.id.playAgainLayout);

        if (array[0] == array[1] && array[0] == array[2] ||
                array[0] == array[4] && array[0] == array[8] ||
                array[0] == array[3] && array[0] == array[6] ||
                array[1] == array[4] && array[1] == array[7] ||
                array[3] == array[4] && array[3] == array[5] ||
                array[6] == array[4] && array[6] == array[2] ||
                array[6] == array[7] && array[6] == array[8] ||
                array[2] == array[5] && array[2] == array[8]) {
            Toast.makeText(this, "Player "+win+" has won the game!", Toast.LENGTH_SHORT).show();

            textView.setText("Player "+win+" has won the game!");

            linearLayout.setVisibility(View.VISIBLE);

            activeState=0;

            wins=1;
        }
        else if (i>=9){

            textView.setText("The game has ended up in draw!");

            linearLayout.setVisibility(View.VISIBLE);

            activeState=0;

            wins=1;
        }
    }

    public void playAgain(View view){

        LinearLayout linearLayout= (LinearLayout) findViewById(R.id.playAgainLayout);

        linearLayout.setVisibility(View.INVISIBLE);

        GridLayout gridLayout=findViewById(R.id.gridLayout);

        for(int m=0;m<gridLayout.getChildCount();m++){
            ((ImageView)gridLayout.getChildAt(m)).setImageResource(0);
//            token.animate().rotation(-360).setDuration(0);
        }
        activePlayer=0;
        for(int k=0;k<array.length;k++) {
            array[k] = k+ 2;
            tags[k]=0;
        }
        i=0;
        win=-1;
        activeState=1;
        wins=0;
        g++;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
    }
}
